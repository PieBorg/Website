const dark = "#2e2e2e";
const light = "#ededed";

document.documentElement.style.setProperty("--background", dark);
document.documentElement.style.setProperty("--foreground", light);